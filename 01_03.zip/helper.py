import os

KeyWords = {'$INSERT':('$INCLUDE'),
'OPEN':('OPF'),
'READ':('F.READ','CACHE.READ'),
'F.READ':('CACHE.READ')
}

global s, w

def file_to_code_convertion():
    VALUE = 'True'
    indexes = []
    words_changed = 0
    with open('original_code.txt') as f:
        lines = f.readlines()

    for row, line in enumerate(lines, 1):
        print('Before', line)
        words = line.split(' ')
        for i in range(len(words)):
            if words[i] in KeyWords.keys():
                words[i] = KeyWords[words[i]]
                w = words[i]
                print('Changed:', words[i])
                words_changed += 1
                if type(words[i]) == tuple:
                    print("Tuple",list(enumerate(words[i])))
                    value_to_insert = int(input("Enter the number to insert the value:"))
                    for value_to_insert, obj in enumerate(words[i]):
                        words[i] = obj
                        w = words[i]


        s = ' '
        with open('converted_code.txt','a+') as F:
            sentence = s.join(words)
            F.write(sentence)
            print("Final", sentence)
            #print('Row', row)
            #print('String Start', sentence.find(w))
            #print('String End', int(sentence.find(w)) + len(w))
            if sentence.find(w) != -1:
                start = '{0}.{1}'.format(row, sentence.find(w))
                end = '{0}.{1}'.format(row, int(sentence.find(w)) + len(w))
                start_end_index = tuple([start, end])
                print(indexes.append(start_end_index))
            print('---------------------------')
    #print("Final Changed Indexes:", indexes)
    return indexes, row, words_changed


def new_code():
    with open('converted_code.txt','r') as read_code:
        code = read_code.read()

    os.remove('converted_code.txt')
    os.remove('original_code.txt')
    return code


class GetPath:
    def __init__(self, path, filename):
        self.path = path
        self.filename = filename
    
    def read_file(self):
        with open(self.path, 'r') as file:
            data = file.read()

        return data

    @classmethod
    def from_input(cls, path):
        path = path
        filename = path.split('/')
        filename = filename[-1]

        return cls(path, filename)