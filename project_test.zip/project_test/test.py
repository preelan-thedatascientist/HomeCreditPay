class PageThree(ttk.Frame):
	"""docstring for StartPage"""
	def __init__(self, parent, controller):
		self. controller = controller
		ttk.Frame.__init__(self, parent)

		rows=0
		while rows < 50:
			self.rowconfigure(rows,weight=1)
			self.columnconfigure(rows,weight=1)
			rows+=1

		imgdir = os.path.join(os.path.dirname(__file__), 'img')
		i1 = tk.PhotoImage("img_close", file='close.gif')
		print('i1', i1)
		i2 = tk.PhotoImage("img_closeactive",file=os.path.join(imgdir, 'close_active.gif'))
		i3 = tk.PhotoImage("img_closepressed",file=os.path.join(imgdir, 'close_pressed.gif'))


		style = ttk.Style()

		style.element_create("close", "image", "img_close",
			("active", "pressed", "!disabled", "img_closepressed"),
    		("active", "!disabled", "img_closeactive"), border=8, sticky='')

		style.layout("ButtonNotebook", [("ButtonNotebook.client", {"sticky": "nswe"})])
		style.layout("ButtonNotebook.Tab", [
			("ButtonNotebook.tab", {"sticky": "nswe", "children":
				[("ButtonNotebook.padding", {"side": "top", "sticky": "nswe",
					"children":
					[("ButtonNotebook.focus", {"side": "top", "sticky": "nswe",
						"children":
						[("ButtonNotebook.label", {"side": "left", "sticky": ''}),
						("ButtonNotebook.close", {"side": "left", "sticky": ''})]
						})]
					})]
				})]
			)


		self.bind_class("TNotebook", "<ButtonPress-1>", self.btn_press, True)
		self.bind_class("TNotebook", "<ButtonRelease-1>", self.btn_release)

		tab = ttk.Notebook(self, width=200, height=200, style="ButtonNotebook")
		#tab.grid(row=0,column = 0,columnspan = 50,rowspan = 49,sticky='NESW)
		tab.pressed_index = None

		paths = ['E:\\Vasumati\\project\\v2.0.3\\DSP.PARAMETER.b', 'E:\\Vasumati\\project\\v2.0.3\\DSP.PARAMETER.b', 'E:\\Vasumati\\project\\v2.0.3\\DSP.PARAMETER.b']

		for i in range(len(paths)):
			tab1 = tk.Frame(tab, background="blue")
			j = GetPath.from_input(paths[i])
			save['Filename'].append(j.filename) 
			save['path'].append(j.path)

			tab.add(tab1, text='{0} |'.format(j.filename))
			#Label(tab1, text= '{0}'.format(paths[i])).place(pady=20, padx=10)

			for i in range(10):
				self.columnconfigure(0, weight=1)
			for i in range(1,10):
				self.rowconfigure(1, weight=1)

			# make a master PanedWindow
			m1 = tk.PanedWindow(self)
			m1.grid(column=0, row=0, rowspan=4, columnspan=4, sticky=E+N+W+S)

			for i in range(4):
				m1.columnconfigure(i, weight=1) # Enable vertical resizing
			for i in range(1,4):
				m1.rowconfigure(i, weight=1) #Enable horizontal resizing

			# make a PanedWindow inside m1, positioned to the left
			m2=PanedWindow(m1, orient=VERTICAL)
			m2.grid(column=0, row=1, columnspan=2, rowspan=2, sticky=E+N+W+S)

			for i in range(2):
				m2.columnconfigure(i, weight=1) # Enable vertical resizing
			for i in range(1,4):
				m2.rowconfigure(i, weight=1) #Enable horizontal reditmenuizing

			# make another PanedWindow inside m1, positioned to the right
			m3=PanedWindow(m1,orient=VERTICAL)
			m3.grid(column=2, row=1, columnspan=2, rowspan=2, sticky=E+N+W+S)

			for i in range(2, 4):
				m3.columnconfigure(i, weight=1) # Enable vertical resizing
			for i in range(1,4):
				m3.rowconfigure(i, weight=1) #Enable horizontal resizing


			test1 = Button(self, text="Button 1", width = 10, height = 6,relief = RAISED, borderwidth = 10)
			test1.grid(column=4, row=0, sticky=E+N+W+S)

			test2 = Button(self, text="Button 2", width = 10, height = 6,relief = RAISED, borderwidth = 10)
			test2.grid(column=4, row=1,sticky=E+N+W+S)

			test3 = Button(self, text="Button 3", width = 10, height = 6,relief = RAISED, borderwidth = 10)
			test3.grid(column=4, row=2,sticky=E+N+W+S)

			test4 = Button(self, text="Button 4", width = 10, height = 6,relief = RAISED, borderwidth = 10)
			test4.grid(column=4, row=3,sticky=E+N+W+S)

			test5 = Button(self, text="Button 5", width = 10, height = 6,relief = RAISED, borderwidth = 10)
			test5.grid(column=4, row=4,sticky=E+N+W+S)	

			test_side_1 = Button(self, text="Button 6", width = 10, height = 6,relief = RAISED, borderwidth = 10)
			test_side_1.grid(column=4, row=5, sticky=E+N+W+S)

			# Add a text widget in m2
			text1 = ScrolledText(m2, height=30, width =15)
			m2.add(text1)
			text1.insert(END, j.read_file())

			# Add another textwidget in m3
			text2=ScrolledText(m3, height=30, width=15)
			m3.add(text2)


			test_down_1 = Button(self, text="Analyse", height = 2, command = lambda: [Message("What to Do?", "Check Your Terminal to pass Inputs."), self.copy_code(text1 , text2)])
			test_down_1.grid(column=0, row=4, sticky=E+N+W+S)


		tab.pack(expand=1, fill='both')


	def btn_press(self, event):
		x, y, widget = event.x, event.y, event.widget
		elem = widget.identify(x, y)
		index = widget.index("@%d,%d" % (x, y))


		if "close" in elem:
			widget.state(['pressed'])
			widget.pressed_index = index

	def btn_release(self, event):
		x, y, widget = event.x, event.y, event.widget


		if not widget.instate(['pressed']):
			return


		elem =  widget.identify(x, y)
		index = widget.index("@%d,%d" % (x, y))


		if "close" in elem and widget.pressed_index == index:
			widget.forget(index)
			widget.event_generate("<<NotebookClosedTab>>")


		widget.state(["!pressed"])
		widget.pressed_index = None

	def copy_code(self, text1, text2):
		#Your code that checks the expression

		varContent = text1.get(1.0, END) # get what's written in the inputentry entry widget

		with open('original_code.txt','w+') as f:
			f.write(varContent)

		index_values, lines, words_changed = file_to_code_convertion()
		text2.delete(1.0, END) # clear the outputtext text widget
		text2.insert(END, new_code())

		for index in index_values:
			text2.tag_add("here", index[0], index[1])
			text2.tag_config("here", background = "yellow", foreground = "blue")

		test_down_2 = ScrolledText(self, height = 4)
		test_down_2.tag_configure("center", justify='center')
		test_down_2.insert("1.0",'{0}---Summary---{1}\n'.format('*'*20, '*'*20))
		test_down_2.insert(END,'{0}         :{1}\n'.format('Total Lines Read', lines))
		test_down_2.insert(END,'{0}	 :{1}'.format('Total Key Words Changed', words_changed))
		test_down_2.tag_add("center","1.0", "end")
		test_down_2.grid(column=0, row=5,sticky=E+N+W+S)