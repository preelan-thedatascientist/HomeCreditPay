with open("DSP.PARAMETER.b", "r") as file:
	data = file.readlines()
with open("out.txt", "w") as f:
	f.write("".join(map(str,data)))