import tkinter as tk
import os
import os.path
from tkinter import *
from tkinter import messagebox, ttk
from tkinter.filedialog import askopenfile, askopenfilenames
from tkinter.scrolledtext import ScrolledText
import tkinter
from tkinter.ttk import *


from helper import GetPath
from helper import *

global save, file_names
save ={
  'Filename':[],
  'ky':[],
  'path':[],
  'raw_text':[],
  'converted_text':[]
}

file_names = {
	'Filename':[]
}


def Message(status, message):
	messagebox.showinfo(status, message)



class app(tk.Tk):
	"""This Class is the main Window for the Application"""
	def __init__(self, *args, **kwargs):
		tk.Tk.__init__(self, *args, **kwargs)

		self.app_data = { "file_list": StringVar()}

		#tk.Tk.iconbitmap(self, default="xyz.ico")
		tk.Tk.wm_title(self, 'Application')
		tk.Tk.minsize(self, 800, 600)
		#self.resizable(False , False)
		#self.attributes('-fullscreen', True)

		imgdir = os.path.join(os.path.dirname(__file__), 'img')
		i1 = tk.PhotoImage("img_close", file=os.path.join(imgdir, 'close.gif'))
		i2 = tk.PhotoImage("img_closeactive",file=os.path.join(imgdir, 'close_active.gif'))
		i3 = tk.PhotoImage("img_closepressed",file=os.path.join(imgdir, 'close_pressed.gif'))


		style = ttk.Style()

		style.element_create("close", "image", "img_close",
			("active", "pressed", "!disabled", "img_closepressed"),
    		("active", "!disabled", "img_closeactive"), border=8, sticky='')

		style.layout("ButtonNotebook", [("ButtonNotebook.client", {"sticky": "nswe"})])
		style.layout("ButtonNotebook.Tab", [
			("ButtonNotebook.tab", {"sticky": "nswe", "children":
				[("ButtonNotebook.padding", {"side": "top", "sticky": "nswe",
					"children":
					[("ButtonNotebook.focus", {"side": "top", "sticky": "nswe",
						"children":
						[("ButtonNotebook.label", {"side": "left", "sticky": ''}),
						("ButtonNotebook.close", {"side": "left", "sticky": ''})]
						})]
					})]
				})]
			)






		#ttk.Style().configure('TFrame',background="white")
		#ttk.Style().configure('TButton',background="Green")
		#ttk.Style().configure('TLabel',background="Yellow")
		#ttk.Style().configure('TText',background="Red")

		container = ttk.Frame(self)
		container.pack(side='top', fill='both', expand = True)


		self.frames = {}

		for F in (StartPage, PageTwo, PageThree, PageFour):
			frame = F(container, self)
			self.frames[F] = frame

			frame.grid(row=0, column=0, sticky='NSEW')

		self.show_frame(StartPage)

		container.grid_rowconfigure(0, weight=1)
		container.grid_columnconfigure(0, weight=1)

		menu = tk.Menu(container)
		tk.Tk.config(self, menu=menu)

		filemenu = tk.Menu(menu, tearoff=1)
		filemenu.add_command(label='New', command=lambda: Message("Alert", "Not Supported Yet."))   # options IN FILE MENU
		filemenu.add_command(label='Open', command=lambda: Message("Alert", "Not Supported Yet.")) # options IN FILE MENU
		filemenu.add_command(label='Save', command=lambda: Message("Alert", "Not Supported Yet.")) # options IN FILE MENU
		filemenu.add_command(label='SaveAS', command=lambda: Message("Alert", "Not Supported Yet."))
		filemenu.add_separator()
		filemenu.add_command(label='Exit', command=self.destroy) #option in FILE MENU

		menu.add_cascade(label='File', menu=filemenu)     #FILE MENU


		options = tk.Menu(menu, tearoff=1)
		options.add_command(label='Single', command=lambda: [self.show_frame(PageTwo), Message("What to Do?", "Write your code Left side of the Panel")])   # options IN OPTION MENU
		options.add_command(label='Multiple', command=lambda: [Message("What to Do?", "Select Files to Analyze"), self.show_frame(PageThree)]) # options IN OPTION MENU

		menu.add_cascade(label='Options', menu=options)     #OPTON MENU


	def show_frame(self, cont):

		frame = self.frames[cont]
		frame.tkraise()

class StartPage(tk.Frame):
	"""docstring for StartPage"""
	def __init__(self, parent, controller):
		self.controller = controller
		ttk.Frame.__init__(self, parent)

		#label = ttk.Label(self, text = 'Hello World..!')
		#label.pack(pady=10, padx=10)

		button1 = ttk.Button(self, text = "Login",command = lambda: [controller.show_frame(PageFour)])
		button1.pack(pady=10, padx=10)

class PageTwo(ttk.Frame):
	"""docstring for StartPage"""
	def __init__(self, parent, controller):
		self.controller = controller
		ttk.Frame.__init__(self, parent)

		for i in range(10):
			self.columnconfigure(0, weight=1)
		for i in range(1,10):
			self.rowconfigure(1, weight=1)

		# make a master PanedWindow
		m1 = tk.PanedWindow(self)
		m1.grid(column=0, row=0, rowspan=4, columnspan=4, sticky=E+N+W+S)

		for i in range(4):
			m1.columnconfigure(i, weight=1) # Enable vertical resizing
		for i in range(1,4):
			m1.rowconfigure(i, weight=1) #Enable horizontal resizing

		# make a PanedWindow inside m1, positioned to the left
		m2=PanedWindow(m1, orient=VERTICAL)
		m2.grid(column=0, row=1, columnspan=2, rowspan=2, sticky=E+N+W+S)

		for i in range(2):
			m2.columnconfigure(i, weight=1) # Enable vertical resizing
		for i in range(1,4):
			m2.rowconfigure(i, weight=1) #Enable horizontal reditmenuizing

		# make another PanedWindow inside m1, positioned to the right
		m3=PanedWindow(m1,orient=VERTICAL)
		m3.grid(column=2, row=1, columnspan=2, rowspan=2, sticky=E+N+W+S)

		for i in range(2, 4):
			m3.columnconfigure(i, weight=1) # Enable vertical resizing
		for i in range(1,4):
			m3.rowconfigure(i, weight=1) #Enable horizontal resizing


		test1 = tk.Button(self, text="Button 1", width = 10, height = 6,relief = RAISED, borderwidth = 10)
		test1.grid(column=4, row=0, sticky=E+N+W+S)

		test2 = tk.Button(self, text="Button 2", width = 10, height = 6,relief = RAISED, borderwidth = 10)
		test2.grid(column=4, row=1,sticky=E+N+W+S)

		test3 = tk.Button(self, text="Button 3", width = 10, height = 6,relief = RAISED, borderwidth = 10)
		test3.grid(column=4, row=2,sticky=E+N+W+S)

		test4 = tk.Button(self, text="Button 4", width = 10, height = 6,relief = RAISED, borderwidth = 10)
		test4.grid(column=4, row=3,sticky=E+N+W+S)

		test5 = tk.Button(self, text="Button 5", width = 10, height = 6,relief = RAISED, borderwidth = 10)
		test5.grid(column=4, row=4,sticky=E+N+W+S)

		test_side_1 = tk.Button(self, text="Button 6", width = 10, height = 6,relief = RAISED, borderwidth = 10)
		test_side_1.grid(column=4, row=5, sticky=E+N+W+S)

		# Add a text widget in m2
		text1 = ScrolledText(m2, height=30, width =15)
		m2.add(text1)

		# Add another textwidget in m3
		text2=ScrolledText(m3, height=30, width=15)
		m3.add(text2)


		test_down_1 = tk.Button(self, text="Analyse", height = 2, command = lambda: [Message("What to Do?", "Check Your Terminal to pass Inputs."), self.copy_code(text1 , text2)])
		test_down_1.grid(column=0, row=4, sticky=E+N+W+S)



	def copy_code(self, text1, text2):
		#Your code that checks the expression

		varContent = text1.get(1.0, END) # get what's written in the inputentry entry widget

		with open('original_code.txt','w+') as f:
			f.write(varContent)

		index_values, lines, words_changed = file_to_code_convertion()
		text2.delete(1.0, END) # clear the outputtext text widget
		text2.insert(END, new_code())

		for index in index_values:
			text2.tag_add("here", index[0], index[1])
			text2.tag_config("here", background = "yellow", foreground = "blue")

		test_down_2 = ScrolledText(self, height = 4)
		test_down_2.tag_configure("center", justify='center')
		test_down_2.insert("1.0",'{0}---Summary---{1}\n'.format('*'*20, '*'*20))
		test_down_2.insert(END,'{0}         :{1}\n'.format('Total Lines Read', lines))
		test_down_2.insert(END,'{0}	 :{1}'.format('Total Key Words Changed', words_changed))
		test_down_2.tag_add("center","1.0", "end")
		test_down_2.grid(column=0, row=5,sticky=E+N+W+S)

class MyTab(Frame):

    def __init__(self, root, name, j):
        Frame.__init__(self, root)

        self.root = root
        self.name = name
        self.j = j


        #self.entry = Entry(self)
        #self.entry.grid(sticky='NESW')

        #self.entry.bind('<FocusOut>', self.alert)
        #self.entry.bind('<Key>', self.printing)

        for i in range(10):
            self.columnconfigure(0, weight=1)
        for i in range(1, 10):
            self.rowconfigure(1, weight=1)


        # make a master PanedWindow

        self.m1 = tk.PanedWindow(self)
        self.m1.grid(column=0, row=0, rowspan=4, columnspan=4, sticky=E+N+W+S)

        for i in range(4):
            self.m1.columnconfigure(i, weight=1) # Enable vertical resizing
        for i in range(1,4):
            self.m1.rowconfigure(i, weight=1) #Enable horizontal resizing

        # make a PanedWindow inside m1, positioned to the left
        self.m2=PanedWindow(self.m1, orient=VERTICAL)
        self.m2.grid(column=0, row=1, columnspan=2, sticky=E+N+W+S)

        for i in range(2):
            self.m2.columnconfigure(i, weight=1) # Enable vertical resizing
        for i in range(1,4):
            self.m2.rowconfigure(i, weight=1) #Enable horizontal reditmenuizing

        # make another PanedWindow inside m1, positioned to the right
        self.m3=PanedWindow(self.m1,orient=VERTICAL)
        self.m3.grid(column=2, row=1, columnspan=2, sticky=E+N+W+S)

        for i in range(2, 4):
            self.m3.columnconfigure(i, weight=1) # Enable vertical resizing
        for i in range(1,4):
            self.m3.rowconfigure(i, weight=1) #Enable horizontal resizing


        self.text1 = ScrolledText(self.m2, height=40, width =15)
        self.m2.add(self.text1)
        self.text1.insert(END, self.j.read_file())
        self.text1.bind('<FocusOut>', self.alert)
        self.text1.bind('<Key>', self.printing)
        #self.text1.insert(END,)

        # Add another textwidget in m3
        self.text2=ScrolledText(self.m3, height=34, width=15)
        self.m3.add(self.text2)

        self.test_down_2 = ScrolledText(self, height = 4)
        self.test_down_2.grid(column=0, row=4,sticky=E+N+W+S)


        self.test_down_1 = tk.Button(self, text="Analyse", command = lambda: [Message("What to Do?", "Check Your Terminal to pass Inputs."), self.copy_code()])
        self.test_down_1.grid(column=0, row=3, sticky='NESW')






    #-------------------------------

    def alert(self, event):
        print ('FocusOut event is working for ' + self.name + '  value: ' + self.text1.get(1.0, END))
        #tkMessageBox.showinfo('alert', 'FocusOut event is working for ' + self.name + '  value: ' + self.entry.get())


    #-------------------------------

    def printing(self, event):
        print (event.keysym + ' for ' + self.name)


    def copy_code(self):
        #Your code that checks the expression
        self.varContent = self.text1.get(1.0, END) # get what's written in the inputentry entry widget

        with open('original_code.txt','w+') as f:
            f.write(self.varContent)

        self.index_values, self.lines, self.words_changed = file_to_code_convertion()
        self.text2.delete(1.0, END) # clear the outputtext text widget
        self.text2.insert(END, new_code(self.name))



        for index in self.index_values:
            self.text2.tag_add("here", index[0], index[1])
            self.text2.tag_config("here", background = "yellow", foreground = "blue")


        self.test_down_2.tag_configure("center", justify='center')
        self.test_down_2.insert("1.0",'{0}---Summary---{1}\n'.format('*'*20, '*'*20))
        self.test_down_2.insert(END,'{0}         :{1}\n'.format('Total Lines Read', self.lines))
        self.test_down_2.insert(END,'{0}     :{1}'.format('Total Key Words Changed', self.words_changed))
        self.test_down_2.tag_add("center","1.0", "end")





class PageThree(ttk.Frame):
	"""docstring for StartPage"""
	def __init__(self, parent, controller):
		self.controller = controller
		ttk.Frame.__init__(self, parent)

		rows=0
		while rows < 50:
			self.rowconfigure(rows,weight=1)
			self.columnconfigure(rows,weight=1)
			rows+=1



		self.bind_class("TNotebook", "<ButtonPress-1>", self.btn_press, True)
		self.bind_class("TNotebook", "<ButtonRelease-1>", self.btn_release)

		self.a = tk.Text(self, height = 1, width = 60)
		self.a.pack(pady=50, padx=10)

		self.button1 = ttk.Button(self, text="Choose", command = self.add_files)
		self.button1.pack(pady=10, padx=10)


	def add_files(self):
		self.a.delete(0.0, END)
		self.file = askopenfilenames( title='Choose a file')


		self.a.insert(0.0, self.file)
		self.button1.destroy()

		self.lab = tk.Label(self, text=self.file)
		self.lab.pack(pady=10, padx=10)


		self.button3 = ttk.Button(self, text="Choose Again", command = self.add_files_again)
		self.button3.pack(pady=10, padx=10)

		self.button4 = ttk.Button(self, text="Proceed", command = self.frameWidgets)
		self.button4.pack(pady=10, padx=10)

	def add_files_again(self):
		self.a.delete(0.0, END)
		self.button3.destroy()
		self.button4.destroy()
		self.lab.destroy()
		self.add_files()


	def frameWidgets(self):
		self.a.destroy()
		self.button3.destroy()
		self.button4.destroy()
		self.lab.destroy()


		self.tabs = {'ky':0}

		self.notebook = ttk.Notebook(self, width=200, height=200, style="ButtonNotebook")
		self.notebook.grid(row=0,column = 0,columnspan = 50,rowspan = 49,sticky='NESW')
		self.notebook.pressed_index = None


		paths = list(self.file)
		print('path', paths)

		for i in range(len(paths)):
			self.tab1 = tk.Frame(self.notebook)
			self.j = GetPath.from_input(paths[i])
			save['ky'].append(self.tabs['ky'])
			save['Filename'].append(self.j.filename)
			save['path'].append(self.j.path)
			save['raw_text'].append(self.j.read_file())
			_, self.lines, self.words_changed = self.lines_words_count()
			save['converted_text'].append(new_code(self.j.filename))



			if self.tabs['ky'] < 26:
				self.tabs['ky'] += 1

				self.addTab(self.j.filename)

		self.notebook.grid(sticky='NSEW')



		for key in save:
			print(key, '->', save[key])


	def lines_words_count(self):
		#Your code that checks the expression
		self.varContent = self.j.read_file() # get what's written in the inputentry entry widget


		with open('original_code.txt','w+') as f:
			f.write(self.varContent)

		self.index_values, self.lines, self.words_changed = file_to_code_convertion()

		return self.index_values, self.lines, self.words_changed




	def btn_press(self, event):
		x, y, widget = event.x, event.y, event.widget
		elem = widget.identify(x, y)
		index = widget.index("@%d,%d" % (x, y))


		if "close" in elem:
			widget.state(['pressed'])
			widget.pressed_index = index

	def btn_release(self, event):
		x, y, widget = event.x, event.y, event.widget


		if not widget.instate(['pressed']):
			return


		elem =  widget.identify(x, y)
		index = widget.index("@%d,%d" % (x, y))


		if "close" in elem and widget.pressed_index == index:
			widget.forget(index)
			widget.event_generate("<<NotebookClosedTab>>")


		widget.state(["!pressed"])
		widget.pressed_index = None

	def addTab(self, name):
		tab = MyTab(self.notebook, name, self.j)
		self.notebook.add(tab, text=name)

class PageFour(tk.Frame):
	"""docstring for StartPage"""
	def __init__(self, parent, controller):
		self.controller = controller
		ttk.Frame.__init__(self, parent)

		button1 = ttk.Button(self, text = "Single",command = lambda: [controller.show_frame(PageTwo)])
		button1.pack(pady=10, padx=10)

		button1 = ttk.Button(self, text = "Multiple",command = lambda: [Message("What to Do?", "Select Files to Analyze"), controller.show_frame(PageThree)])
		button1.pack(pady=10, padx=10)








app = app()
app.mainloop()
