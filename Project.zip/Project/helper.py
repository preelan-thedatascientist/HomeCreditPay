Dict = {'$INSERT':('$INCLUDE '),
'OPEN':('OPF '),
'READ':('F.READ','CACHE.READ '),
'F.READ':('CACHE.READ ')
}

global s

def file_to_code_convertion():
    with open('original_code.txt') as f:
        lines = f.readlines()

    for line in lines:
        print('Before', line)
        words = line.split(' ')
        for i in range(len(words)):
            if words[i] in Dict.keys():
                words[i] = Dict[words[i]]
                if type(words[i]) == tuple:
                    print("Tuple",list(enumerate(words[i])))
                    value_to_insert = int(input("Enter the number to insert the value:"))
                    for value_to_insert, obj in enumerate(words[i]):
                        words[i] = obj


        s = " "
        with open('converted_code.txt','a+') as F:
            F.write(s.join(words))
            print('After', s.join(words))
            print()



def new_code():
    with open('converted_code.txt','r') as read_code:
        code = read_code.read()
    return code
