import tkinter as tk
from tkinter import *
from tkinter import messagebox, ttk
from tkinter.filedialog import askopenfile, askopenfilenames
from tkinter.scrolledtext import ScrolledText

from helper import GetPath

global save, file_names
save ={
  'Filename':[],
  'path':[]
}

file_names = {
	'Filename':[]
}




#------------------------------------------------------------

def Message(status, message):
	messagebox.showinfo(status, message)


def print_cmd(param):
	print(param)


def open_file():
	#file = askopenfile(mode ='r', filetypes =[('Python Files', '*.py')]) 
	file = askopenfilenames( title='Choose a file')
	file = list(file)

	for i in file:
		file_names['Filename'].append(i)
	print(file_names)


#------------------------------------------------------------
def Editor(self):
	for i in range(10):
		self.columnconfigure(0, weight=1)
	for i in range(1,10):
		self.rowconfigure(1, weight=1)

	# make a master PanedWindow
	m1 = tk.PanedWindow(self)
	m1.grid(column=0, row=0, rowspan=4, columnspan=4, sticky=E+N+W+S)

	for i in range(4):
		m1.columnconfigure(i, weight=1) # Enable vertical resizing
	for i in range(1,4):
		m1.rowconfigure(i, weight=1) #Enable horizontal resizing

	# make a PanedWindow inside m1, positioned to the left
	m2=PanedWindow(m1, orient=VERTICAL)
	m2.grid(column=0, row=1, columnspan=2, rowspan=2, sticky=E+N+W+S)

	for i in range(2):
		m2.columnconfigure(i, weight=1) # Enable vertical resizing
	for i in range(1,4):
		m2.rowconfigure(i, weight=1) #Enable horizontal reditmenuizing

	# make another PanedWindow inside m1, positioned to the right
	m3=PanedWindow(m1,orient=VERTICAL)
	m3.grid(column=2, row=1, columnspan=2, rowspan=2, sticky=E+N+W+S)

	for i in range(2, 4):
		m3.columnconfigure(i, weight=1) # Enable vertical resizing
	for i in range(1,4):
		m3.rowconfigure(i, weight=1) #Enable horizontal resizing


	test1 = Button(self, text="Button 1", width = 10, height = 6,relief = RAISED, borderwidth = 10)
	test1.grid(column=4, row=0, sticky=E+N+W+S)

	test2 = Button(self, text="Button 2", width = 10, height = 6,relief = RAISED, borderwidth = 10)
	test2.grid(column=4, row=1,sticky=E+N+W+S)

	test3 = Button(self, text="Button 3", width = 10, height = 6,relief = RAISED, borderwidth = 10)
	test3.grid(column=4, row=2,sticky=E+N+W+S)

	test4 = Button(self, text="Button 4", width = 10, height = 6,relief = RAISED, borderwidth = 10)
	test4.grid(column=4, row=3,sticky=E+N+W+S)

	test5 = Button(self, text="Button 5", width = 10, height = 6,relief = RAISED, borderwidth = 10)
	test5.grid(column=4, row=4,sticky=E+N+W+S)

	test_down_1 = Button(self, text="Analyse", height = 2)
	test_down_1.grid(column=0, row=4, sticky=E+N+W+S)

	test_down_2 = ScrolledText(self, height = 4)
	test_down_2.tag_configure("center", justify='center')
	test_down_2.insert(END,'{0}---Summary---{1}'.format('*'*20, '*'*20))
	test_down_2.tag_add("center","1.0", "end")
	test_down_2.grid(column=0, row=5,sticky=E+N+W+S)
	

	test_side_1 = Button(self, text="Button 6", width = 10, height = 6,relief = RAISED, borderwidth = 10)
	test_side_1.grid(column=4, row=5, sticky=E+N+W+S)

	return m2, m3


	


#--------------------------------------------------------------

class app(tk.Tk):
	"""This Class is the main Window for the Application"""
	def __init__(self, *args, **kwargs):
		tk.Tk.__init__(self, *args, **kwargs)

		#tk.Tk.iconbitmap(self, default="xyz.ico")
		tk.Tk.wm_title(self, 'Application')
		#tk.Tk.minsize(self, 800, 600)
		self.resizable(False , False)
		self.attributes('-fullscreen', True)
		
		style=ttk.Style(self)
		style.theme_create( "body", parent="alt", settings={
			"TNotebook": {"configure": {"tabmargins": [7, 5, 2, 0] , "background": "#253042" }},
			"TNotebook.Tab": {
			"configure": {"padding": [5, 1], "background": "#253042" , "foreground":"white"},
			"map":       {"background": [("selected", "black")],
			"expand": [("selected", [2, 3, 3, 0])] }},
			"TProgressbar":{"configure": {"background": "orange" , "troughcolor":"#253042","borderwidth":"5"}}
			})


		style.theme_use("body")
		
		ttk.Style().configure('TFrame',background="white")
		ttk.Style().configure('TButton',background="Green")
		ttk.Style().configure('TLabel',background="Yellow")
		ttk.Style().configure('TText',background="Red")

		container = ttk.Frame(self, style='TFrame')
		container.pack(side='top', fill='both', expand = True)

		

		

		self.frames = {}

		for F in (StartPage, PageTwo, PageThree):
			frame = F(container, self)
			self.frames[F] = frame

			frame.grid(row=0, column=0, sticky='NSEW')

		self.show_frame(StartPage)

		container.grid_rowconfigure(0, weight=1)
		container.grid_columnconfigure(0, weight=1)

		menu = tk.Menu(container) 
		tk.Tk.config(self, menu=menu) 

		filemenu = tk.Menu(menu, tearoff=1) 
		filemenu.add_command(label='New', command=lambda: Message("Alert", "Not Supported Yet."))   # options IN FILE MENU         
		filemenu.add_command(label='Open', command=lambda: Message("Alert", "Not Supported Yet.")) # options IN FILE MENU  
		filemenu.add_command(label='Save', command=lambda: Message("Alert", "Not Supported Yet.")) # options IN FILE MENU  
		filemenu.add_command(label='SaveAS', command=lambda: Message("Alert", "Not Supported Yet."))
		filemenu.add_separator() 
		filemenu.add_command(label='Exit', command=self.destroy) #option in FILE MENU

		menu.add_cascade(label='File', menu=filemenu)     #FILE MENU


		options = tk.Menu(menu, tearoff=1) 
		options.add_command(label='Single', command=lambda: self.show_frame(PageTwo))   # options IN OPTION MENU         
		options.add_command(label='Multiple', command=lambda: self.show_frame(PageThree)) # options IN OPTION MENU  

		menu.add_cascade(label='Options', menu=options)     #OPTON MENU


	def show_frame(self, cont):

		frame = self.frames[cont]
		frame.tkraise()



class StartPage(tk.Frame):
	"""docstring for StartPage"""
	def __init__(self, parent, controller):
		ttk.Frame.__init__(self, parent)
		
		#label = ttk.Label(self, text = 'Hello World..!')
		#label.pack(pady=10, padx=10)

		button1 = ttk.Button(self, text = "Login",command = lambda: [open_file(), controller.show_frame(PageTwo)])
		button1.pack(pady=10, padx=10)

class PageTwo(ttk.Frame):
	"""docstring for StartPage"""
	def __init__(self, parent, controller):
		ttk.Frame.__init__(self, parent)

		single_m2, single_m3 = Editor(self)

		# Add a text widget in m2
		text1 = Text(single_m2, height=30, width =15)
		single_m2.add(text1)

		# Add another textwidget in m3
		text2=Text(single_m3, height=30, width=15)
		single_m3.add(text2)


class PageThree(ttk.Frame):
	"""docstring for StartPage"""
	def __init__(self, parent, controller):
		ttk.Frame.__init__(self, parent)
		#self.filena = filena

		rows=0
		while rows < 50:
			self.rowconfigure(rows,weight=1)
			self.columnconfigure(rows,weight=1)
			rows+=1

		tab = ttk.Notebook(self)
		tab.grid(row=0,column = 0,columnspan = 50,rowspan = 49,sticky='NESW')


		paths = ['E:\\Vasumati\\project\\v2.0.2/DSP.PARAMETER.b']
		#paths = file

		for i in range(len(paths)):
			tab1 = ttk.Frame(tab, style='My.TFrame')
			j = GetPath.from_input(paths[i])
			save['Filename'].append(j.filename) 
			save['path'].append(j.path)

			tab.add(tab1,text='{0}'.format(j.filename))
			#Label(tab1, text= '{0}'.format(paths[i])).place(pady=20, padx=10)

			multiple_m2, multiple_m3 = Editor(tab1)

			# Add a text widget in m2
			text1 = ScrolledText(multiple_m2, height=30, width =15)
			multiple_m2.add(text1)
			text1.insert(END, j.read_file())

			# Add another textwidget in m3
			text2=Text(multiple_m3, height=30, width=15)
			multiple_m3.add(text2)
			text2.insert(END, j.path)
	'''
	@classmethod		
	def from_class(cls):
		filena = askopenfilenames(title='Choose a file', filetypes =[('B File', '*.b')])
		return cls(filena)'''



app = app()
app.mainloop()





		