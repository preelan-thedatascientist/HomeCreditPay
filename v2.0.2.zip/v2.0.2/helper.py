class GetPath:
  def __init__(self, path, filename):
    self.path = path
    self.filename = filename
    
  def read_file(self):
    with open(self.path, 'r') as file:
      data = file.read()
    return data
  
  @classmethod
  def from_input(cls, path):
    path, filename = path, path.split('/')
    return cls(path, filename[-1])